package com.ali.daytankoil;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.SharedPreferences;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private final double[] liters = {0,10,20,30,40,50,60,70,80,90,100,110,120,130,140,150,160,170,180,190,200,208};
    private final double[] cm = {1.27,5.41,8.71,11.53,14.12,16.56,18.90,21.16,23.37,25.55,27.71,29.87,32.03,34.21,36.45,38.71,41.07,43.54,46.15,49.05,52.50,55.88};
    private EditText previousInput, currentInput;
    private TextView currentResult, consumptionResult, historyView;
    private SharedPreferences prefs;
    private LinearLayout root;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("day_tank_data", MODE_PRIVATE);
        buildScreen();
        refreshHistory();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    private void buildScreen() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18),dp(18),dp(18),dp(28)); root.setBackgroundColor(Color.rgb(244,247,250));
        scroll.addView(root); setContentView(scroll);

        TextView title = text("DAY TANK MONITOR", 23, Color.WHITE, true);
        TextView subtitle = text("Oil level & 24-hour consumption", 13, Color.rgb(220,235,247), false);
        LinearLayout header = new LinearLayout(this); header.setOrientation(LinearLayout.VERTICAL); header.setPadding(dp(18),dp(20),dp(18),dp(20)); header.setBackground(bg(Color.rgb(24,75,112),18));
        header.addView(title); subtitle.setPadding(0,dp(5),0,0); header.addView(subtitle); root.addView(header);

        addSpace(root,16); root.addView(text("ENTER LEVEL READINGS",15,Color.rgb(45,58,70),true)); addSpace(root,8);
        previousInput = input("24 hours before level (CM)"); currentInput = input("Current oil level (CM)");
        root.addView(previousInput); addSpace(root,10); root.addView(currentInput); addSpace(root,14);

        Button calculate = button("CALCULATE & SAVE", Color.rgb(24,112,78));
        calculate.setOnClickListener(v -> calculateAndSave()); root.addView(calculate); addSpace(root,10);
        Button clear = button("CLEAR INPUTS", Color.rgb(91,105,117));
        clear.setOnClickListener(v -> { previousInput.setText(""); currentInput.setText(""); currentResult.setText("— L"); consumptionResult.setText("— L"); }); root.addView(clear);

        addSpace(root,18); root.addView(text("CALCULATION RESULTS",15,Color.rgb(45,58,70),true)); addSpace(root,8);
        currentResult = resultCard("CURRENT OIL QUANTITY", "— L"); root.addView(currentResult); addSpace(root,10);
        consumptionResult = resultCard("24-HOUR OIL CONSUMPTION", "— L"); root.addView(consumptionResult);

        addSpace(root,20); root.addView(text("SAVED DAILY HISTORY",15,Color.rgb(45,58,70),true)); addSpace(root,8);
        historyView = text("No saved readings yet.",14,Color.rgb(55,67,78),false); historyView.setPadding(dp(14),dp(14),dp(14),dp(14)); historyView.setBackground(bg(Color.WHITE,14)); root.addView(historyView);
        addSpace(root,10);
        Button deleteHistory = button("CLEAR SAVED HISTORY", Color.rgb(164,65,65));
        deleteHistory.setOnClickListener(v -> { prefs.edit().remove("history").apply(); refreshHistory(); Toast.makeText(this,"History cleared",Toast.LENGTH_SHORT).show(); }); root.addView(deleteHistory);
        addSpace(root,16);
        TextView note = text("Offline calculator • Uses the supplied tank calibration scale (0–208 L).",11,Color.GRAY,false); root.addView(note);
    }
    private EditText input(String hint) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setTextSize(17); e.setHint(hint); e.setInputType( android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setPadding(dp(14),dp(12),dp(14),dp(12)); e.setBackground(bg(Color.WHITE,12)); return e;
    }
    private Button button(String label, int color) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setTextSize(14); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setAllCaps(false); b.setBackground(bg(color,12));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,dp(52)); b.setLayoutParams(p); return b;
    }
    private TextView resultCard(String label, String initial) {
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(15),dp(12),dp(15),dp(12)); card.setBackground(bg(Color.WHITE,14));
        TextView heading = text(label,11,Color.GRAY,true); TextView value = text(initial,25,Color.rgb(24,112,78),true);
        card.addView(heading); value.setPadding(0,dp(5),0,0); card.addView(value);
        root.addView(card); return value;
    }
    private void addSpace(LinearLayout parent, int height) { View v = new View(this); parent.addView(v,new LinearLayout.LayoutParams(1,dp(height))); }

    private double toLiters(double reading) {
        if (reading <= cm[0]) return 0;
        if (reading >= cm[cm.length-1]) return liters[liters.length-1];
        for (int i=0;i<cm.length-1;i++) {
            if (reading <= cm[i+1]) {
                return liters[i] + (reading-cm[i])*(liters[i+1]-liters[i])/(cm[i+1]-cm[i]);
            }
        }
        return 0;
    }
    private void calculateAndSave() {
        String p = previousInput.getText().toString().trim(); String c = currentInput.getText().toString().trim();
        if (p.isEmpty() || c.isEmpty()) { Toast.makeText(this,"Enter both CM readings",Toast.LENGTH_SHORT).show(); return; }
        try {
            double prevCm = Double.parseDouble(p), currCm = Double.parseDouble(c);
            if (prevCm < cm[0] || prevCm > cm[cm.length-1] || currCm < cm[0] || currCm > cm[cm.length-1]) {
                Toast.makeText(this,"Enter CM reading between 1.27 and 55.88",Toast.LENGTH_LONG).show(); return;
            }
            double prevL = toLiters(prevCm), currL = toLiters(currCm), used = prevL-currL;
            currentResult.setText(String.format(Locale.US,"%.2f L",currL));
            if (used >= 0) consumptionResult.setText(String.format(Locale.US,"%.2f L",used));
            else consumptionResult.setText(String.format(Locale.US,"Oil increased by %.2f L",Math.abs(used)));
            ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(currentInput.getWindowToken(),0);
            JSONObject item = new JSONObject();
            item.put("date",new SimpleDateFormat("dd MMM yyyy, hh:mm a",Locale.getDefault()).format(new Date()));
            item.put("previousCm",prevCm); item.put("currentCm",currCm); item.put("previousLiters",prevL); item.put("currentLiters",currL); item.put("consumption",used);
            JSONArray arr = new JSONArray(prefs.getString("history","[]")); arr.put(0,item); prefs.edit().putString("history",arr.toString()).apply(); refreshHistory();
            Toast.makeText(this,"Reading saved",Toast.LENGTH_SHORT).show();
        } catch (Exception ex) { Toast.makeText(this,"Please enter valid numbers",Toast.LENGTH_SHORT).show(); }
    }
    private void refreshHistory() {
        if (historyView == null) return;
        try {
            JSONArray arr = new JSONArray(prefs.getString("history","[]"));
            if (arr.length()==0) { historyView.setText("No saved readings yet."); return; }
            StringBuilder s = new StringBuilder();
            for (int i=0;i<arr.length();i++) {
                JSONObject o=arr.getJSONObject(i);
                s.append(o.optString("date")).append("\n")
                 .append(String.format(Locale.US,"Previous: %.2f cm (%.2f L)\nCurrent: %.2f cm (%.2f L)\n",o.optDouble("previousCm"),o.optDouble("previousLiters"),o.optDouble("currentCm"),o.optDouble("currentLiters")));
                double used=o.optDouble("consumption");
                if (used>=0) s.append(String.format(Locale.US,"Consumption: %.2f L",used));
                else s.append(String.format(Locale.US,"Oil increased: %.2f L",Math.abs(used)));
                if (i<arr.length()-1) s.append("\n\n──────────────\n\n");
            }
            historyView.setText(s.toString());
        } catch(Exception e) { historyView.setText("Unable to load history."); }
    }
}
