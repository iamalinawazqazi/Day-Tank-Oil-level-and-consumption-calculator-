DAY TANK OIL CALCULATOR - ANDROID PROJECT

Features
- Offline CM-to-liter conversion using the calibration points transcribed from your supplied scale.
- 24-hour consumption from previous-day and current CM readings.
- Saves calculation history locally on the phone.
- Shows an oil increase separately if current quantity is greater than the previous quantity.

BUILD APK ON GITHUB (NO COMPUTER / ANDROID STUDIO REQUIRED)
1. Create a GitHub repository named Day-Tank-Oil-Calculator and choose the main branch.
2. Upload ALL CONTENTS of this project folder to the ROOT of that repository (not the outer DayTankOilApp folder).
3. Make sure .github/workflows/android.yml is present in the repository at exactly that path.
4. Commit the uploaded files to the main branch.
5. Open the repository's Actions tab. Select "Build Android APK" and press "Run workflow" if it has not started automatically.
6. Wait for the workflow to finish with a green check mark.
7. Open the completed workflow run, scroll to Artifacts, and download "Day-Tank-Oil-Calculator-APK".
8. Extract the downloaded artifact ZIP and install app-debug.apk on the Android phone. Allow installation from this source if Android asks.

Application ID: com.ali.daytankoil
Minimum Android version: Android 6.0 (API 23)
The APK built by this workflow is a debug APK for personal installation/testing.
